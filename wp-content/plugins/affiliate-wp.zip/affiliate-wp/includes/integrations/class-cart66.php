<?php

class Affiliate_WP_Cart66 extends Affiliate_WP_Base {
	
	
}